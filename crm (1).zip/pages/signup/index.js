import Signup from "@/components/signup";
export default Signup;