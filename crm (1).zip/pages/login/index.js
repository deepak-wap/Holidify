import Login from "@/components/login";
export default Login;