import {update, remove, fetchById} from '@/controller/company.controller'

const company = (req,res)=>{
    if(req.method === "GET") return fetchById(req,res)
    if(req.method === "PUT") return update(req,res)
    if(req.method === "DELETE") return remove(req,res)
    res.status(405).send("Method not allowed!")
}

export default company