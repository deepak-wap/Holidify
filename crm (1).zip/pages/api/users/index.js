import {create, fetch} from '@/controller/users.controller'

const users = (req,res)=>{
    if(req.method === "GET") return fetch(req,res)
    if(req.method === "POST") return create(req,res)
    res.status(405).send("Method not allowed!")
}

export default users