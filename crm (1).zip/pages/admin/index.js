import Admin from "@/components/admin";
import jwt from 'jsonwebtoken'

const AdminRoute = (data)=>{
    console.log(data)
    return <Admin />
}

export default AdminRoute

export const getServerSideProps = (context)=>{
    try {
        const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY1NDUxNjFhODJjNDkwMDUwNzk2YTMzMyIsImNvbXBhbnkiOiI2NTQ1MTYxYTgyYzQ5MDA1MDc5NmEzMzAiLCJmb3VuZGVyIjoiZGFzZmRzIiwiZ3N0Ijoic2RhZmRzIiwiZW1haWwiOiJzYWRmZHNAZ21haWwuY29tIiwiaWF0IjoxNjk5MDI2NDU4LCJleHAiOjE2OTk2MzEyNTh9.KvtL9jU7HDKrr3daAWU0DhNg94OGzLMSNMo7rFNTetQ"
        const session = jwt.verify(token,process.env.NEXT_PUBLIC_JWT_SECRET)
        return {
            props: session
        }
    }
    catch(err)
    {
        return {
            redirect: {
                destination: '/login',
                permanent: false
            }
        }
    }
}