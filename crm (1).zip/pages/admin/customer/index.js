import Customer from "@/components/admin/customer";
export default Customer;