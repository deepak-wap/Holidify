import mongoose from 'mongoose'
const {Schema} = mongoose

const companySchema = new Schema({
    companyName: {type: String, required: true},
    founder: {type: String, required: true},
    gst: String,
    createdAt: {type: Date, default: Date.now}
})

companySchema.pre('save',async function(next){
    const count = await mongoose.model("Company").countDocuments({companyName: this.companyName})
    if(count) throw next(new Error("Company name already exist"))

    // Forward request
    next()
})

mongoose.models = {}
const Company = mongoose.model("Company",companySchema)
export default Company