import "@/modules/db"
import Company from '@/schema/company.schema'

export const fetch = async (req,res)=>{
    const companies = await Company.find(req.query)
    res.status(200).json(companies)
}

export const fetchById = async (req,res)=>{
    try {
        const company = await Company.findById(req.query.id)
        res.status(200).json(company)
    }
    catch(err)
    {
        res.status(500).json({err: err.message})
    }
}

export const create = async (req,res)=>{
    try {
        const company = new Company(req.body)
        await company.save()
        res.status(200).json(company)
    }
    catch(err)
    {
        res.status(500).json({err: err.message})
    }
}

export const update = async (req,res)=>{
    try {
        await Company.updateOne({_id: req.query.id},req.body)
        res.status(200).json({success: true})
    }
    catch(err)
    {
        res.status(500).json({err: err.message})
    }
}

export const remove = async (req,res)=>{
    try {
        await Company.deleteOne({_id: req.query.id})
        res.status(200).json({success: true})
    }
    catch(err)
    {
        res.status(500).json({err: err.message})
    }
}