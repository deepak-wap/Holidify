import '@/modules/db'
import User from '@/schema/user.schema'

export const create = async (req,res)=>{
    try {
        const user = new User(req.body)
        await user.save()
        user.password = undefined
        res.status(200).json(user)
    }
    catch(err)
    {
        res.status(200).json({err: err.message})
    }
}

export const fetchById = async (req,res)=>{
    try {
        const {populate} = req.query
        let user = null

        if(populate === "true") 
        user = await User.findById(req.query.id).populate("company")

        else
        user = await User.findById(req.query.id)
    
        res.status(200).json(user)
    }
    catch(err)
    {
        res.status(200).json({err: err.message})
    }
}

export const fetch = async (req,res)=>{
    try {
        const user = await User.findOne(req.query)
        if(!user) return res.status(404).json({err: 'User doesn`t exist'})
        res.status(200).json(user)
    }
    catch(err)
    {
        res.status(500).json({err: err.message})
    }
}