import axios from 'axios'
axios.defaults.baseURL = process.env.NEXT_PUBLIC_ENDPOINT 
import cookie from 'cookie'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcrypt'

export const signup = async (req,res)=>{
    const {companyName, founder, gst, email, mobile, password} = req.body
    try {
        const {data: Company} = await axios.post('/api/company',{companyName, founder, gst})
        const {data: User} = await axios.post('/api/users',{email, mobile, password, company: Company._id})
        const token = jwt.sign({
            id: User._id,
            company: User.company,
            founder: Company.founder,
            gst: Company.gst,
            email: User.email
        },
        process.env.NEXT_PUBLIC_JWT_SECRET,
        {expiresIn: "7d"}
        )

        const cookieData = cookie.serialize('authToken',token,{
            httpOnly: true,
            maxAge: 60
        })
        res.setHeader('Set-Cookie',cookieData)
        res.status(200).json({success: true})
    }
    catch(err)
    {
        res.status(500).json(err)
    }
}

export const login = async (req,res)=>{
    try {
        const {email, password} = req.body
        const {data: User} = await axios.get(`/api/users?email=${email}`)
        
        const auth = await bcrypt.compare(password,User.password)
        if(!auth) return res.status(401).json({success: false})

        const token = jwt.sign({
            id: User._id,
            company: User.company,
            email: User.email
        },
        process.env.NEXT_PUBLIC_JWT_SECRET,
        {expiresIn: "7d"}
        )

        const cookieData = cookie.serialize('authToken',token,{
            httpOnly: true,
            maxAge: 60
        })
        res.setHeader('Set-Cookie',cookieData)
        res.status(200).json({success: true})
    }
    catch(err)
    {
        res.status(err.response.status).json(err.response.data)
    }
}